make clean pour supprimer tous les fichier temporaires et exécutables. 

make pour construire l'exe de l'exercice 4 

make big pour construire l'exe de l'exercice 5

main.exe pour l'exercice 4 

bigMain.exe l'exercice 5 